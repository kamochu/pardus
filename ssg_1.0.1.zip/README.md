# pardus
Pardus is an SMS gateway solution that integrates with Huawei SDP.
