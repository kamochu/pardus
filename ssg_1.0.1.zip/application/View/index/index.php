<div class="container">
    <h1>Sematel SMS Gateway (SSG)</h1>
    <div class="box">
        <h3>Introduction</h3>
        <p>SSG is Sematel SMS Gateway that will handle all communication requests between Sematel Premium Rated Services and Safaricom Service Delivery Platform (SDP).
        </p>
        <p>Sematel is a licensed Premium Rated Services (PRS) provider in Kenya.</p>
    </div>
</div>
